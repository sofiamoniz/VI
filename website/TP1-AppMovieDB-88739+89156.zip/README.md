    RI, December 2020
    Group assignment: Aplicação para Exploração Visual de Dados - Visualização de Informação
    Authors: Ana Sofia Fernandes, 88739
             Pedro Oliveira, 89156

**With this platform, it is possible for the user to find the movie platform that suits him the most.
It should be noted that this data may not apply to all countries.**

### To run:
    Due to D3.js, the website has to be running live. Thus, we advice to open "index.html" by using Visual Code with the extension "Live Server". 

### Note:

-**The code is located in the folder "code"**

-**The pdf report can be found in the folder "report"**

-**The final presentation can be found in the folder "presentation"**

-**The platform's video can be found on slide 5 of the presentation**
